package examples.pubhub.dao;

import java.util.List;

import examples.pubhub.model.BookTag;

public interface BookTagDAO {
	
	public List<BookTag> getAllBookTags();
	public List<BookTag> getAllBooks();
	public List<BookTag> getTagsByBook(String isbn13);
	public List<BookTag> getBooksByTag(String tag);
	
	public boolean addBookTag(BookTag Booktag);
	public boolean deleteBookTag(BookTag Booktag);
}
