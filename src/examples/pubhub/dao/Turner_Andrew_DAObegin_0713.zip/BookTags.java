package examples.pubhub.model;

public class BookTags {
	
	private String isbn13;			// International Standard Book Number, unique
	private String tag;				// Book tags
	
	//Default Constructor
	public BookTags() {
		this.isbn13 = null;
		this.tag = null;
	}
	
	public String getIsbn13() {
		return isbn13;
	}
	public void setIsbn13(String isbn13) {
		this.isbn13 = isbn13;
	}
	public String getTags() {
		return tag;
	}
	public void setTags(String tag) {
		this.tag = tag;
	}
	
	
}
