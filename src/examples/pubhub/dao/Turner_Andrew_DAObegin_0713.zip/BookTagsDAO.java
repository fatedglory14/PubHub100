package examples.pubhub.dao;

import java.util.List;

import examples.pubhub.model.BookTags;

public interface BookTagsDAO {
	public List<BookTags> getAllBookTags();
	public List<BookTags> getAllBooks();
	public List<BookTags> getTagsByBook(String isbn13);
	public List<BookTags> getBooksByTag(String tag);
	
	public boolean addBookTag(String tag, String isbn13);
	public boolean deleteBookTag(String tag, String isbn13);
}
